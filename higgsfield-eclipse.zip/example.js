(() => {
  /* Original Higgsfield browser-shipped drawing, spring, and handoff code.
   * Extracted and formatted from ae0a6d00-pn2LeQlr4keTLhu3.js.
   * The standalone adapter follows the extracted engine below.
   */

  function t(initialize) {
    let pending = initialize;
    return () => {
      const run = pending;
      pending = undefined;
      return run?.();
    };
  }

  const de = (value) => String(value);

  function me(e) {
    let t = ``,
      n = 0,
      r = 0;
    return {
      fadeAt: (n) => {
        let r = _e((n - he.from) / he.seconds),
          i = (r * r * (3 - 2 * r)).toFixed(2);
        i !== t && ((t = i), (e.style.opacity = i));
      },
      leanTo: (t, i) => {
        let a = Math.round(t);
        a === n ||
          i - r < ge ||
          ((n = a),
          (r = i),
          e.style.setProperty(`--eclipse-glow-lean`, String(a)));
      },
      reset: () => {
        ((t = `0`),
          (n = 0),
          (e.style.opacity = `0`),
          e.style.setProperty(`--eclipse-glow-lean`, `0`));
      },
    };
  }
  var he, ge, _e;
  function ve() {
    return (ve = t(() => {
      ((he = { from: 0.3, seconds: 1.4 }),
        (ge = 66),
        (_e = (e) => Math.min(Math.max(e, 0), 1)));
    }))();
  }
  function ye(e, t) {
    let n = null,
      r = 1,
      i = 0,
      a = !0,
      o = (e) => (n ? n.time + ((e - n.nowMs) / 1e3) * r : 0),
      s = (e) => {
        if (((i = 0), !n || !a)) return;
        let r = Math.min((e - n.lastMs) / 1e3, 0.1) || 1 / 60;
        ((n.lastMs = e), t(o(e), r, e), (i = requestAnimationFrame(s)));
      },
      c = new IntersectionObserver(([e]) => {
        var t;
        ((a = (t = e == null ? void 0 : e.isIntersecting) == null || t),
          a && n && !i && (i = requestAnimationFrame(s)));
      });
    return (
      c.observe(e),
      {
        isRunning: () => n !== null,
        start: (e, t) => {
          ((n = { time: e, nowMs: t, lastMs: t }),
            (i = requestAnimationFrame(s)));
        },
        stop: () => {
          (cancelAnimationFrame(i), (n = null));
        },
        setRate: (e) => {
          let t = performance.now();
          (n && (n = { ...n, time: o(t), nowMs: t }), (r = e));
        },
        dispose: () => {
          (cancelAnimationFrame(i), c.disconnect());
        },
      }
    );
  }
  function be(e, t) {
    return t === `roll`
      ? { planetRise: 0, numberRise: 0, alpha: 1 }
      : {
          planetRise: 0.02 * (1 - Ee(e / 1.4, 5)),
          numberRise: 0.07 * (1 - Ee((e - 0.8) / 1.2, 5)),
          alpha: De(e - 0.8),
        };
  }
  function xe(e, t, n) {
    let r = Te((e - t) / 1.9),
      i = n - Oe + Oe * Ee(r, 4);
    if (i >= n) return [j(Math.floor(n / 10)), A, j(n), A];
    let a = Math.floor(i),
      o = i - a,
      s = 28 * (1 - r) ** 3,
      c = (1 - o) ** 1.5,
      l = [j(a, -o, c, s), j(a + 1, 1 - o, 1, s)],
      [u, d] = [Math.floor(a / 10), Math.floor((a + 1) / 10)];
    return [
      ...(u === d || o <= 0 ? [j(u), A] : [j(u, -o, c, s), j(d, 1 - o, 1, s)]),
      ...l,
    ];
  }
  function Se(e, { size: t, planet: n }, r) {
    var i, a;
    let { width: o, height: s } = t,
      [c = 0, l = 0, u = o, d = s] =
        (i =
          (a = e.getAttribute(`viewBox`)) == null
            ? void 0
            : a.split(` `).map(Number)) == null
          ? []
          : i,
      f = n.radius * s,
      p = o * (0.5 + n.shift) - c,
      m = s * (1 - (n.top - n.radius - r)) - l;
    return `path(evenodd, "M0 0H${u}V${d}H0Z M${p - f} ${m} a${f} ${f} 0 1 0 ${2 * f} 0 a${f} ${f} 0 1 0 ${-2 * f} 0Z")`;
  }
  function Ce(e, t) {
    let n = (t) => e.querySelector(`[data-eclipse-number="${t}"]`),
      [r, i, a] = [n(`light`), n(`dodge`), n(`line`)];
    if (!r || !i || !a) throw Error(`Eclipse number markup is missing a layer`);
    let o = [r, i, a].map((e) => e.lastElementChild),
      s = [...e.querySelectorAll(`[data-dg]`)].map(
        (e) => (
          e.firstChild instanceof Text || e.append(``),
          { element: e, glyph: e.firstChild }
        ),
      ),
      c = r.querySelector(`.sun`),
      l = r.querySelector(`.sun2`),
      {
        idPrefix: u,
        rollBase: d,
        rollTravel: f,
        horizonY: p,
        twinEdgeY: m,
        sunStretch: h,
      } = t.number.geometry,
      { width: g, height: _ } = t.size,
      v = ``,
      y = ``,
      b = (e) => {
        let n = xe(e, t.number.rollStartsAt, t.number.value),
          r = n.map(([e, t, n]) => `${e}${t.toFixed(3)}${n.toFixed(2)}`).join();
        if (r !== v) {
          v = r;
          for (let { element: e, glyph: t } of s) {
            var i;
            let [r, a, o, s] = (i = n[Number(e.dataset.dg)]) == null ? A : i;
            (t.data !== r && (t.data = r),
              e.setAttribute(`y`, (d + a * f).toFixed(1)),
              e.setAttribute(`opacity`, o.toFixed(3)));
            let c = ke(s);
            c
              ? e.setAttribute(`filter`, `url(#${u}mb${c})`)
              : e.removeAttribute(`filter`);
          }
        }
      },
      x = (e, t, n) => {
        let r = (t, n, r) => {
          (t == null || t.setAttribute(`cx`, String(e)),
            t == null || t.setAttribute(`cy`, String(n)),
            t == null ||
              t.setAttribute(
                `gradientTransform`,
                `translate(${e} ${n}) scale(${r} 1) translate(${-e} ${-n})`,
              ));
        };
        (r(c, p - t, h * (1 + 0.3 * n)), r(l, m + t, 2.4));
      };
    return {
      update: (e, n, s) => {
        b(e);
        let { planetRise: c, numberRise: l, alpha: u } = be(e, t.number.intro),
          d = (l + c) * _,
          f = g * (0.5 + t.planet.shift) + Math.sin(n) * t.planet.radius * _,
          p = `${d.toFixed(1)}|${Math.round(f / 2) * 2}|${s.toFixed(2)}|${u.toFixed(3)}`;
        if (p !== y) {
          y = p;
          for (let e of o)
            e == null || e.setAttribute(`transform`, `translate(0 ${d})`);
          for (let e of [r, i, a])
            e.style.clipPath = l > 5e-4 ? Se(e, t, c) : `none`;
          ((r.style.opacity = String(we.light * u)),
            (i.style.opacity = String(we.dodge * u)),
            (a.style.opacity = String(u)),
            x(f, d, s));
        }
      },
    };
  }
  var we, A, Te, Ee, De, Oe, j, ke;
  function Ae() {
    return (Ae = t(() => {
      ((we = { light: 0.85, dodge: 0.2 }),
        (A = [``, 1, 0, 0]),
        (Te = (e) => Math.min(Math.max(e, 0), 1)),
        (Ee = (e, t) => 1 - (1 - Te(e)) ** t),
        (De = (e) => {
          let t = Te(e);
          return t * t * (3 - 2 * t);
        }),
        (Oe = 7),
        (j = (e, t = 0, n = 1, r = 0) => [String(e % 10), t, n, r]),
        (ke = (e) =>
          e < 1.5 ? 0 : e < 5 ? 2 : e < 11 ? 6 : e < 19 ? 12 : 22));
    }))();
  }
  function je(e) {
    return { time: e, peak: 0, boost: 0, wave: -1, parallax: [0, 0] };
  }
  function Me() {
    let e = 0,
      t = 0,
      n = [0, 0],
      r = 0,
      i = 0,
      a = 0,
      o = -1,
      s = null,
      c = (n, r) => {
        for (let i = r; i > 1e-6; i -= Ie) {
          let r = Math.min(Ie, i);
          ((t += ((n - e) * 38 - t * 11) * r), (e += t * r));
        }
      };
    return {
      pointAt: (e, t) => {
        s = { x: e, y: t };
      },
      release: () => {
        s = null;
      },
      hoverCta: (e, t) => {
        ((a = +!!e), e && (o < 0 || t - o > Re) && (o = t));
      },
      advance: (t, l, u) => {
        var d;
        c(s ? Pe * Math.tanh(s.x * 1.4) : 0, l);
        let f = 1 - Math.exp(-l * 4);
        ((n = [
          n[0] + (((d = s == null ? void 0 : s.x) == null ? 0 : d) - n[0]) * f,
          n[1] + ((s ? 0.5 - s.y : 0) - n[1]) * f,
        ]),
          (r += (a - r) * (1 - Math.exp(-l * 10))),
          (i +=
            ((s ? Fe * Math.tanh(s.x * 1.6) : 0) - i) *
            (1 - Math.exp(-l * 3))));
        let p = (u - o) / 1e3;
        return {
          scene: {
            time: t,
            peak: e,
            boost: r,
            wave: o >= 0 && p < Le ? p : -1,
            parallax: n,
          },
          glowLean: i,
        };
      },
    };
  }
  function Ne(e, t) {
    let n = (n) => {
        let r = e.getBoundingClientRect();
        t().pointAt(
          ((n.clientX - r.left) / r.width - 0.5) * (r.width / r.height),
          (n.clientY - r.top) / r.height,
        );
      },
      r = () => t().release();
    return (
      window.addEventListener(`pointermove`, n),
      document.addEventListener(`pointerleave`, r),
      () => {
        (window.removeEventListener(`pointermove`, n),
          document.removeEventListener(`pointerleave`, r));
      }
    );
  }
  var Pe, Fe, Ie, Le, Re;
  function ze() {
    return (ze = t(() => {
      ((Pe = 0.2), (Fe = 35), (Ie = 1 / 240), (Le = 3.2), (Re = 2500));
    }))();
  }
  var Be, Ve;
  function He() {
    return (He = t(() => {
      ((Be = `attribute vec2 p; void main(){ gl_Position = vec4(p, 0., 1.); }`),
        (Ve = `precision highp float;
  uniform vec2 uRes; uniform sampler2D uTex; uniform float uPx;
  uniform int uLayer, uTexMode; uniform float uTwin, uTwinY, uCx; uniform float uDith, uNumA; uniform vec2 uNumBox; uniform float uLines, uGrain, uWave; uniform vec2 uPar; uniform float uTime, uIgn, uRays, uRise, uPeak, uBoost, uNumOff, uTop, uR, uFlare, uHoverNum;
  uniform vec3 uBg, uW0, uW1, uW2, uW3, uC0, uC1, uC2, uC3, uDeep, uBody;
  float h1(float n){ return fract(sin(n * 127.1) * 43758.5453); }
  float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
  float n1(float x){ float i = floor(x), f = fract(x); return mix(h1(i), h1(i + 1.), f * f * (3. - 2. * f)); }
  float gs(float x, float w){ return exp(-x * x / max(w * w, 1e-6)); }
  // gradient map: intensity -> colour (deep, saturated, hot, white)
  vec3 ramp(float x, vec3 a, vec3 b, vec3 c, vec3 d){
    x = max(x, 0.);
    vec3 col = mix(vec3(0.), a, smoothstep(0., .18, x));
    col = mix(col, b, smoothstep(.12, .45, x));
    col = mix(col, c, smoothstep(.4, .85, x));
    col = mix(col, d, smoothstep(.8, 1.4, x));
    return mix(col, vec3(1.), smoothstep(1.3, 2.4, x));
  }
  // 4-scale glow around a distance (>= 0)
  float glow4(float d, float k){ return k * (.9 * exp(-d / .004) + .55 * exp(-d / .013) + .3 * exp(-d / .04) + .16 * exp(-d / .13)); }
  vec2 dirA(float a){ return vec2(sin(a), cos(a)); }
  // 4x4 ordered dither to 24 levels: a visible, regular print-like texture in the gradients
  float b2(vec2 a){ return mod(a.x + 2. * a.y, 4.) == 0. ? 0. : (mod(a.x + 2. * a.y, 4.) == 1. ? 2. : (mod(a.x + 2. * a.y, 4.) == 2. ? 3. : 1.)); }
  // 8x8 ordered dither: a fine, even print-like pattern (no noise, no coarse grid); softened so it reads as texture, not posterization
  float bb2(vec2 a){ a = floor(a); return fract(dot(a, vec2(.5, a.y * .75))); }
  float b8(vec2 a){ return (bb2(.25 * a) * .25 + bb2(.5 * a)) * .25 + bb2(a); }
  vec3 bayer(vec3 c){ float th = b8(gl_FragCoord.xy / uDith);
    float L = 8.; vec3 q = floor(c * L + th) / L; return mix(c, q, .65); }
  void main(){
    vec2 p = vec2((gl_FragCoord.x - uRes.x * .5) / uRes.y, gl_FragCoord.y / uRes.y);
    float px = uPx;                                   // one device pixel in scene units
    float boost = 1. + .5 * uBoost;
    vec2 c = vec2(uCx, uTop - uR - uRise);   // uCx: the eclipse can sit off-centre in a format (card, pricing)
    vec2 v = p - c; float r = length(v); float d = r - uR;
    float th = atan(v.x, v.y); float dth = th - uPeak;
    float t = uTime;
    // Clean eclipse (ref: two planets, one hot gap): a long thin rim, light only where the sun is, no haze, no rays.
    // Two angular profiles: the rim line runs far to the sides, the bloom stays tight around the sun.
    float lineSpread = mix(.03, .46, uIgn) * (1. + .15 * uBoost);   // the rim fades toward the sides, centred on the light (follows the pointer)
    float glowSpread = mix(.02, .16, uIgn) * (1. + .25 * uBoost);
    float shimmer = .9 + .1 * n1(th * 18. - t * .5);
    float Al = gs(dth, lineSpread) * shimmer, Ag = gs(dth, glowSpread);
    vec2 P = c + uR * dirA(uPeak);                    // the hottest point of the rim
    vec2 dp = p - P;
    vec2 tang = vec2(cos(uPeak), -sin(uPeak));        // along the rim at the sun
    float along = dot(dp, tang), across = dot(dp, -vec2(sin(uPeak), cos(uPeak)) * -1.);
    // the bloom is a flat ellipse along the horizon, several sizes added
    float e1 = length(vec2(along * .22, across)), e2 = length(vec2(along * .3, across * 1.3)), e3 = length(vec2(along * .4, across * 1.8));
    // two blooms: the tight one for the sky (no haze), the earlier wide one only where the number is,
    // so the light on the digits stays as rich as before while the sky around them stays clean
    float onNum = texture2D(uTex, gl_FragCoord.xy / uRes + vec2(0., uNumOff + uRise)).r * uNumA;   // no ghost of the number before it appears
    float bloomSky = (2.4 * exp(-e1 / .014) + .7 * exp(-e2 / .05) + .03 * exp(-e3 / .2));
    float bloomNum = (2.2 * exp(-e1 / .014) + .7 * exp(-e2 / .055) + .07 * exp(-e3 / .2));
    float bloom = mix(bloomSky, bloomNum, onNum) * uIgn * boost;

    float lines = 0.;   // side lines removed
    float beams = 0.;
    // bloom runs a few pixels under the planet edge so the low-res sky never shows a stepped edge next to the crisp rim
    float under = smoothstep(-10. * px, -3. * px, d);
    // depth: sparse faint stars with a little pointer parallax (they sit far behind the planet)
    vec2 sp2 = (p + uPar * .012) * 70.; vec2 cell = floor(sp2); vec2 fp = fract(sp2) - .5;
    float hs = hash(cell); vec2 off = vec2(hash(cell + 3.1), hash(cell + 7.7)) - .5;
    float star = step(.93, hs) * exp(-length(fp - off * .7) / (.035 + .03 * hash(cell + 1.3))) * (.55 + .45 * sin(t * (.6 + hs * 2.) + hs * 40.));
    star *= smoothstep(.0, .25, d) * .5;
    float shade = 1.;
    // full bloom behind the number: the number's plus-lighter layer adds it, which makes its base white-hot
    vec3 col = uBg + ramp(bloom * under * shade + lines + beams, uW0, uW1, uW2, uW3) + vec3(1., .9, .85) * star;   // the front layer adds the rest of the bloom over the number

    // twin planet hanging from the top, mirrored: its light falls down onto the BLACK FRIDAY label
    vec2 c2 = vec2(uCx, uTwinY + uR); vec2 v2 = p - c2; float d2 = length(v2) - uR;
    float dth2 = atan(v2.x, -v2.y) - uPeak;
    vec2 P2 = c2 + uR * vec2(sin(uPeak), -cos(uPeak)); vec2 dq = p - P2;
    float bloom2 = (2.2 * exp(-length(vec2(dq.x * .22, dq.y)) / .014) + .7 * exp(-length(vec2(dq.x * .3, dq.y * 1.3)) / .05)) * uIgn * boost;
    // uTwin: 1 = the planet with its light, 2 = only its light (the planet itself stays invisible, the glow spills down softly)
    // 2 = light only: nothing in the sky, the label alone is lit (its own gradient in the page)
    if (uTwin > .5 && uTwin < 1.5 && uLayer == 0) col += ramp(bloom2 * .6 * step(0., d2), uW0, uW1, uW2, uW3);
    float dn = hash(gl_FragCoord.xy) + hash(gl_FragCoord.xy + 17.31) - 1.;
    float grain = 0.;
    if (uTexMode == 1) grain = (hash(gl_FragCoord.xy + fract(t * 13.7) * 91.) - .5) * .03;
    if (uTexMode == 3) { vec2 cc = floor(gl_FragCoord.xy / 2.); grain = (hash(cc + floor(t * 24.) * 7.31) - .5) * .07; }
    if (uTexMode == 2) col = bayer(col);
    if (uLayer == 0) { gl_FragColor = vec4(col + dn / 255. + grain * (.4 + col), 1.); return; }

    // ===== front layer (over the number): planet body, rim, glints. Premultiplied: alpha 0 light adds onto the page
    float cover = 1. - smoothstep(-px, px, d);
    // planet: near-black body; a thin lit band just under the rim that follows the line, brighter under the sun
    // the body is lit from the sun point outward (an ellipse wide along the horizon), not as one even band:
    // bright right under the light, fading toward the sides and down into the planet
    vec2 eP = (p - P) * vec2(.34, 1.7); float eD = length(eP);
    float Ia = (1.1 * exp(-eD / .045) + .38 * exp(-eD / .13) + .07 * exp(-eD / .34)) * uIgn * boost
             + .45 * exp(d / .006) * Al * uIgn * boost;
    float sideB = smoothstep(.15, .95, abs(dth) / max(lineSpread, 1e-3));
    col = cover * (uBody + ramp(Ia, uW0, uW1, mix(uW2, uC2, sideB), mix(uW3, uW2, sideB * .8)));
    // rim: crisp line, a touch thicker under the sun, with a tight halo; bloom continues over the line
    float tw = mix(.0007, .0024, Ag) * (1. + .3 * uBoost);
    float band = smoothstep(-px, px, d) * (1. - smoothstep(tw - px, tw + px, d));
    float db = d < 0. ? -d : max(d - tw, 0.);
    float sideK = smoothstep(.15, .95, abs(dth) / max(lineSpread, 1e-3));
    vec3 w2s = mix(uW2, uC2, sideK), w3s = mix(uW3, uW2, sideK * .8);
    float Ir = (band * 2.4 + .7 * exp(-db / .0025)) * Al + .35 * exp(-db / .01) * Ag;
    col += ramp(Ir * uIgn * boost + bloom * .5 * step(0., d), uW0, uW1, w2s, w3s);
    // glints: horizontal streaks leaving the sun to the left and right, a thin bright line in a soft one (the ref's flare)
    vec2 uvS = vec2(P.x * uRes.y / uRes.x + .5, P.y) + vec2(0., uNumOff + uRise);
    float occS = 0.;
    for (int k = 0; k < 5; k++) { float fk = float(k); vec2 o = .035 * vec2(cos(fk * 1.2566), sin(fk * 1.2566)) * vec2(uRes.y / uRes.x, 1.); occS += texture2D(uTex, uvS + o).r; }
    float vis = (1. - .45 * occS / 5.) * uIgn * boost * (.85 + .5 * uFlare);
    float dx = p.x - P.x, dy = p.y - P.y;
    // glint: a short soft horizontal flare hugging the sun (no screen-wide line)
    float ax = abs(dx);
    float streak = (exp(-abs(dy) / .0009) * .7 + .12 * exp(-abs(dy) / .003)) * exp(-ax * ax / .012);
    col += ramp(streak * 1.05 * vis, uW0, uW1, uW2, uW3) + vec3(1.) * exp(-length(vec2(dx * .5, dy)) / .0035) * .7 * vis;

    // ripples: hairline rings leave the rim like circles on water; strongest under the sun, fading to the sides and as they grow.
    // Full resolution, and cut out where the number is, so they pass behind it. The CTA sends one brighter ring.
    float rip = 0.;
    for (int k = 0; k < 3; k++) {
      float ph = fract(t * .09 + float(k) / 3.);
      float rr = ph * 1.05;
      rip += exp(-abs(d - rr) / (.0007 + ph * .0012)) * pow(1. - ph, 3.) * smoothstep(0., .05, ph);
    }
    rip *= .8 * gs(dth, .45) * exp(-length(p - P) / .9);   // fades with distance from the light
    float wave = 0.;
    // the CTA ring: fast at first, slowing down like a ring on water (ease-out), fading over ~2.5 s
    if (uWave >= 0.) { float wd = .5 * (1. - exp(-uWave * 1.1)); wave = exp(-abs(d - wd) / (.0012 + wd * .003)) * exp(-uWave * 1.4) * 1.5 * gs(dth, .5 + wd) * smoothstep(0., .015, wd); }
    float numMask = 1. - texture2D(uTex, gl_FragCoord.xy / uRes + vec2(0., uNumOff + uRise)).r;
    // the number's area (its width, up to its top): rings fade there so it stays clean, and read best to the left and right
    float inBox = (1. - smoothstep(uNumBox.x * .85, uNumBox.x * 1.15, abs(p.x - uCx))) * (1. - smoothstep(uNumBox.y - .02, uNumBox.y + .06, p.y + uNumOff + uRise));
    numMask *= 1. - .45 * inBox;   // the glyphs themselves cut the rings; the area around them only dims them
    // rings in our orange directly (a faint value through the gradient map would come out almost black)
    col += (mix(uW2, uC2, .7) * rip + ramp(wave, uW0, uW1, uW2, uW3)) * step(0., d) * numMask * uIgn;
    // depth: a second, fainter atmosphere layer just inside the limb (like the stacked shells in the Cyclone ref)
    col += cover * ramp(.32 * exp(-abs(d + .016) / .0016) * Al * uIgn + .12 * exp(-abs(d + .016) / .008) * Ag * uIgn, uW0, uW1, uW2, uW3);
    if (uTwin > .5 && uTwin < 1.5) {
      float cov2 = 1. - smoothstep(-px, px, d2);
      float Al2 = gs(dth2, lineSpread) * shimmer, Ag2 = gs(dth2, glowSpread);
      float eD2 = length(dq * vec2(.34, 1.7));
      float Ia2 = (1.1 * exp(-eD2 / .045) + .38 * exp(-eD2 / .13)) * uIgn * boost + .45 * exp(d2 / .006) * Al2 * uIgn * boost;
      col = mix(col, uBody + ramp(Ia2, uW0, uW1, uW2, uW3), cov2);
      float tw2 = mix(.0007, .0024, Ag2) * (1. + .3 * uBoost);
      float band2 = smoothstep(-px, px, d2) * (1. - smoothstep(tw2 - px, tw2 + px, d2));
      float db2 = d2 < 0. ? -d2 : max(d2 - tw2, 0.);
      col += ramp(((band2 * 2.4 + .7 * exp(-db2 / .0025)) * Al2 + .35 * exp(-db2 / .01) * Ag2) * uIgn * boost + bloom2 * .5 * step(0., d2), uW0, uW1, uW2, uW3);
      cover = max(cover, cov2);
    }
    if (uTexMode == 2) col = bayer(col);
    col += cover * grain * (.5 + col);
    // valid premultiplied output: light gets alpha = its brightness (composites like a screen blend), the planet body is opaque.
    // (rgb > alpha with alpha 0 only "adds" in some renderers; Chrome on a real GPU drops it.)
    col += dn / 255. * cover;
    float la = clamp(max(col.r, max(col.g, col.b)), 0., 1.);
    gl_FragColor = vec4(min(col, vec3(max(cover, la))), max(cover, la));
  }`));
    }))();
  }
  function Ue() {
    return (Ue = t(() => {}))();
  }
  function We() {
    return (We = t(() => {}))();
  }
  function Ge() {
    return (Ge = t(() => {}))();
  }
  var Ke, qe, Je, Ye, Xe;
  function Ze() {
    return (Ze = t(() => {
      ((Ke = { back: 1, front: 1.5 }),
        (qe = [
          `400 100px "Michroma"`,
          `700 100px "SG Full"`,
          `500 64px "Saira Semi Condensed"`,
        ]),
        (Je = (e) => {
          let t = Number.parseInt(e.slice(1), 16);
          return [
            ((t >> 16) & 255) / 255,
            ((t >> 8) & 255) / 255,
            (t & 255) / 255,
          ];
        }),
        (Ye = {
          uBg: `#010104`,
          uBody: `#010206`,
          uC2: `#2f5bff`,
          uW0: `#030d2f`,
          uW1: `#0e2d9d`,
          uW2: `#b57bff`,
          uW3: `#e9d7ff`,
        }),
        (Xe = {
          ...Object.fromEntries(Object.entries(Ye).map(([e, t]) => [e, Je(t)])),
          uIgn: 1,
          uFlare: 0,
          uRise: 0,
          uNumOff: 0,
          uNumA: 1,
          uTexMode: 2,
          uTwin: 2,
        }));
    }))();
  }
  function st(e, t, n) {
    let r = e.createShader(t);
    if (!r) throw Error(`Eclipse shader could not be created`);
    return (e.shaderSource(r, n), e.compileShader(r), r);
  }
  async function ct(e, t) {
    let n = e.getExtension(`KHR_parallel_shader_compile`);
    if (n)
      for (; !e.getProgramParameter(t, n.COMPLETION_STATUS_KHR);) {
        if (e.isContextLost()) throw Error(`WebGL context was lost`);
        await mt();
      }
  }
  async function lt(e) {
    let t = e.createProgram();
    if (!t) throw Error(`Eclipse program could not be created`);
    let n = [st(e, e.VERTEX_SHADER, Be), st(e, e.FRAGMENT_SHADER, Ve)];
    for (let r of n) e.attachShader(t, r);
    if (
      (e.linkProgram(t),
      await ct(e, t),
      !e.getProgramParameter(t, e.LINK_STATUS))
    )
      throw Error(
        n
          .map((t) => e.getShaderInfoLog(t))
          .join(` `)
          .trim() || `Eclipse program failed to link`,
      );
    return (
      e.useProgram(t),
      e.bindBuffer(e.ARRAY_BUFFER, e.createBuffer()),
      e.bufferData(
        e.ARRAY_BUFFER,
        new Float32Array([-1, -1, 3, -1, -1, 3]),
        e.STATIC_DRAW,
      ),
      e.enableVertexAttribArray(0),
      e.vertexAttribPointer(0, 2, e.FLOAT, !1, 0, 0),
      t
    );
  }
  function ut(e, t) {
    (e.bindTexture(e.TEXTURE_2D, e.createTexture()),
      e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MIN_FILTER, e.LINEAR),
      e.texParameteri(e.TEXTURE_2D, e.TEXTURE_MAG_FILTER, e.LINEAR),
      e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_S, e.CLAMP_TO_EDGE),
      e.texParameteri(e.TEXTURE_2D, e.TEXTURE_WRAP_T, e.CLAMP_TO_EDGE),
      e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL, !0),
      e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !0),
      e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, t));
  }
  function dt(e, t, n, r) {
    typeof r == `number`
      ? pt.has(n)
        ? e.uniform1i(t, r)
        : e.uniform1f(t, r)
      : r.length === 2
        ? e.uniform2fv(t, new Float32Array(r))
        : e.uniform3fv(t, new Float32Array(r));
  }
  async function ft(e, t) {
    let n = e.getContext(`webgl`, {
      antialias: !1,
      preserveDrawingBuffer: !1,
      premultipliedAlpha: !0,
      alpha: t.front,
    });
    if (!n) throw Error(`WebGL is unavailable`);
    let r = await lt(n),
      i = (e) => n.getUniformLocation(r, e);
    ((e.width = Math.trunc(t.size.width * t.pixelRatio)),
      (e.height = Math.trunc(t.size.height * t.pixelRatio)),
      n.viewport(0, 0, e.width, e.height),
      ut(n, t.occluder));
    let a = {
      ...t.uniforms,
      uLayer: +!!t.front,
      uCx: (t.shift * e.width) / e.height,
      uRes: [e.width, e.height],
      uPx: 1 / e.height,
      uDith: Math.max(1, Math.round(e.height / t.size.height)),
    };
    for (let [e, t] of Object.entries(a)) dt(n, i(e), e, t);
    let o = {
      time: i(`uTime`),
      peak: i(`uPeak`),
      boost: i(`uBoost`),
      wave: i(`uWave`),
      parallax: i(`uPar`),
    };
    return {
      draw: ({ time: e, peak: t, boost: r, wave: i, parallax: a }) => {
        (n.uniform1f(o.time, e),
          n.uniform1f(o.peak, t),
          n.uniform1f(o.boost, r),
          n.uniform1f(o.wave, i),
          n.uniform2f(o.parallax, a[0], a[1]),
          n.drawArrays(n.TRIANGLES, 0, 3));
      },
      release: () => {
        var t;
        e.isConnected ||
          (t = n.getExtension(`WEBGL_lose_context`)) == null ||
          t.loseContext();
      },
    };
  }
  var pt, mt;
  function ht() {
    return (ht = t(() => {
      (He(),
        (pt = new Set([`uLayer`, `uTexMode`])),
        (mt = () => new Promise((e) => requestAnimationFrame(e))));
    }))();
  }
  async function gt(e) {
    let t = new Image();
    return ((t.crossOrigin = `anonymous`), (t.src = e), await t.decode(), t);
  }
  async function _t(e, t, n, r) {
    let i = t.occluder(n),
      [a, o] = await Promise.all([gt(i.back), gt(i.front)]);
    if (r()) return [];
    let s = { size: t.size, uniforms: t.uniforms, shift: t.planet.shift },
      c = (e) => Math.min(window.devicePixelRatio, e),
      l = await Promise.all([
        ft(e.back, { ...s, front: !1, pixelRatio: c(Ke.back), occluder: a }),
        ft(e.front, { ...s, front: !0, pixelRatio: c(Ke.front), occluder: o }),
      ]);
    if (!r()) return l;
    for (let e of l) e.release();
    return [];
  }
  function vt(e) {
    return Promise.all(e.map((e) => document.fonts.load(e)));
  }
  function yt() {
    return (yt = t(() => {
      (Ze(), ht());
    }))();
  }
  function xt(e, t, n, r) {
    let i = me(e.glow),
      a = null,
      o = 1,
      s = !1;
    return {
      glow: i,
      report: (e) => {
        e !== a && ((a = e), r.onPhase(e));
      },
      showVideo: (t) => {
        t !== o && ((o = t), (e.video.style.opacity = String(t)));
      },
      pose: (a, o = !1) => {
        (o || n == null || n.update(a.time, a.peak, a.boost), i.fadeAt(a.time));
        let c = a.time >= t.copyAt ? `on` : ``;
        if (
          (e.stage.dataset.ui !== c && (e.stage.dataset.ui = c),
          !s && t.giftAt !== void 0 && a.time >= t.giftAt)
        ) {
          var l;
          ((s = !0), (l = r.onGiftIn) == null || l.call(r));
        }
      },
      resetGift: () => {
        s = !1;
      },
    };
  }
  function St(e) {
    let t = () => {};
    return {
      next: (n) => {
        if ((t(), Et())) {
          let r = e.requestVideoFrameCallback((e, { mediaTime: t }) => n(e, t));
          t = () => e.cancelVideoFrameCallback(r);
          return;
        }
        let r = requestAnimationFrame((t) => n(t, e.currentTime));
        t = () => cancelAnimationFrame(r);
      },
      cancel: () => t(),
    };
  }
  function Ct(e, t) {
    let { live: n } = t.spot;
    return t.mode !== `handoff` || !n || !e.live
      ? null
      : {
          format: n.formats[de(t.value, t.label)],
          handOff: n.handOff,
          elements: e.live,
        };
  }
  async function wt(e, t, n) {
    if (!e) return [];
    let [r] = await Promise.all([_t(e.elements, e.format, t, n), vt(qe)]);
    if (!n()) return r;
    for (let e of r) e.release();
    return [];
  }
  function Tt(e, t) {
    let { video: n, stage: r } = e,
      { spot: i } = t,
      a = Ct(e, t),
      {
        glow: o,
        report: s,
        showVideo: c,
        pose: l,
        resetGift: u,
      } = xt(e, i, a ? Ce(a.elements.number, a.format) : null, t),
      d = St(n),
      f = [],
      p = Me(),
      m = 1,
      h = !1,
      g = 0,
      _ = (e) => f.forEach((t) => t.draw(e)),
      v = ye(r, (e, n, r) => {
        var i;
        (i = t.onTime) == null || i.call(t, e);
        let { scene: a, glowLean: s } = p.advance(e, n, r);
        (l(a), o.leanTo(s, r), _(a));
      }),
      y = (e, t) => {
        (n.pause(), c(0), s(`live`), v.start(e, t));
      },
      b = (e, r) => {
        var o;
        if (h || v.isRunning() || n.ended) return;
        let u = r * i.speed;
        (o = t.onTime) == null || o.call(t, u);
        let p = je(u),
          m = a && f.length > 0 ? a.handOff : null,
          g = m !== null && u >= m.warmUpAt;
        (l(p, !g), g && _(p));
        let x = m ? Dt((u - m.handOffAt) / m.fadeSeconds) : 0;
        if ((c(1 - x), x >= 1)) return y(u, e);
        (s(x > 0 ? `fading` : `video`), d.next(b));
      },
      x = (e) => {
        if (h || v.isRunning()) return;
        let t = n.duration * i.speed;
        if (f.length > 0) return y(t, performance.now());
        ((n.currentTime = n.duration), l(je(t), !0), s(e));
      },
      S = () => x(`ended`),
      C = (e) => {
        if (!(h || e !== g)) {
          if ((d.cancel(), Number.isFinite(n.duration))) return x(`blocked`);
          n.addEventListener(`loadedmetadata`, () => C(e), { once: !0 });
        }
      },
      w = () => {
        h || f.length === 0 || (v.stop(), (f = []), c(1), s(`ended`));
      },
      T = wt(a, t.scale, () => h).then(
        (e) => {
          f = e;
        },
        (e) => t.onError(Ot(e)),
      ),
      E = a ? Ne(e.scene, () => p) : null,
      D = a ? [a.elements.back, a.elements.front] : [];
    for (let e of D) e.addEventListener(`webglcontextlost`, w);
    n.addEventListener(`ended`, S);
    let ee = () => {
      ((g += 1),
        v.stop(),
        d.cancel(),
        n.pause(),
        (n.currentTime = 0),
        c(1),
        o.reset(),
        (r.dataset.ui = ``),
        s(`held`));
    };
    return (
      ee(),
      {
        hold: ee,
        replay: () => {
          let e = ++g;
          T.then(() => {
            h ||
              e !== g ||
              (v.stop(),
              (p = Me()),
              o.reset(),
              u(),
              l(je(0), !0),
              c(1),
              (n.muted = !0),
              (n.currentTime = 0),
              (n.playbackRate = m),
              s(`video`),
              d.next(b),
              n.play().catch(() => C(e)));
          });
        },
        setRate: (e) => {
          (v.setRate(e), (m = e), (n.playbackRate = e));
        },
        hoverCta: (e) => {
          v.isRunning() && p.hoverCta(e, performance.now());
        },
        dispose: () => {
          ((h = !0), d.cancel());
          for (let e of D) e.removeEventListener(`webglcontextlost`, w);
          v.dispose();
          for (let e of f) e.release();
          ((f = []),
            n.pause(),
            n.removeEventListener(`ended`, S),
            E == null || E());
        },
      }
    );
  }
  var Et, Dt, Ot;
  function kt() {
    return (kt = t(() => {
      (Ze(),
        ve(),
        yt(),
        Ae(),
        ze(),
        (Et = () => `requestVideoFrameCallback` in HTMLVideoElement.prototype),
        (Dt = (e) => Math.min(Math.max(e, 0), 1)),
        (Ot = (e) => (e instanceof Error ? e : Error(String(e)))));
    }))();
  }

  /* Standalone adapter for the captured pricing/69 scene. */
  const stage = document.querySelector(".eclipse-stage");
  const host = stage.parentElement;
  const scene = stage.querySelector("[data-scene]");
  const number = stage.querySelector("[data-number]");
  const [back, front] = scene.querySelectorAll("canvas");
  const video = stage.querySelector("video");
  const glow = stage.querySelector(".eclipse-glow");
  const motion = window.matchMedia("(prefers-reduced-motion: reduce)");

  kt();

  const size = { width: 1072, height: 240 };
  const horizon = 0.3645241854532161;
  const planet = { radius: 2.2, top: horizon, shift: -0.22 };
  const format = {
    size,
    planet,
    uniforms: {
      ...Xe,
      uR: planet.radius,
      uTop: horizon,
      uTwinY: 0.874875814546784,
      uNumBox: [0.7955722312987646, 0.6755880614416204],
    },
    number: {
      value: 69,
      intro: "rise",
      rollStartsAt: 0.9,
      geometry: {
        idPrefix: "pricing-69-",
        rollBase: 177.6508652540111,
        rollTravel: 107.77536000000002,
        horizonY: 152.51419549122815,
        twinEdgeY: 30.02980450877184,
        sunStretch: 1.9,
      },
    },
    occluder: () => ({
      back: "./media/occluder-back.png",
      front: "./media/occluder-front-2x.png",
    }),
  };
  const spot = {
    size,
    speed: 1,
    copyAt: 1.7,
    live: {
      formats: { 69: format },
      handOff: { warmUpAt: 1.9, handOffAt: 2.2, fadeSeconds: 0.3 },
    },
  };

  new ResizeObserver(([entry]) => {
    stage.style.setProperty(
      "--banner-scale",
      String(entry.contentRect.width / size.width),
    );
  }).observe(host);

  const digits = [...stage.querySelectorAll(".eclipse-digit")];
  const demoEnd = Date.now() + (9 * 3600 + 35 * 60 + 21) * 1000;
  function renderCountdown() {
    const remaining = Math.max(0, Math.ceil((demoEnd - Date.now()) / 1000));
    const parts = [
      Math.floor(remaining / 3600),
      Math.floor(remaining / 60) % 60,
      remaining % 60,
    ];
    const characters = parts
      .map((part) => String(part).padStart(2, "0"))
      .join("");
    digits.forEach((digit, index) => {
      if (digit.dataset.v === characters[index]) return;
      digit.textContent = characters[index];
      digit.dataset.v = characters[index];
    });
  }

  let player;
  let fallback;
  let timer;
  function stop() {
    player?.dispose();
    player = undefined;
    clearTimeout(fallback);
    clearInterval(timer);
    host.dataset.mode = "still";
  }

  function start() {
    stop();
    if (motion.matches) return;

    const source = video.querySelector("source");
    if (!video.canPlayType(source.type)) {
      source.src = "./media/intro-2x.h264.mp4";
      source.type = "video/mp4";
      video.load();
    }

    player = Tt(
      { stage, scene, number, video, glow, live: { back, front, number } },
      {
        spot,
        mode: "handoff",
        value: 69,
        scale: "2x",
        onError: stop,
        onPhase(phase) {
          if (phase === "live") {
            clearTimeout(fallback);
            host.dataset.mode = "live";
          } else if (phase === "video" || phase === "fading") {
            host.dataset.mode = "intro";
          } else if (phase === "blocked" || phase === "ended") {
            stop();
          }
        },
      },
    );
    fallback = setTimeout(stop, 10_000);
    renderCountdown();
    timer = setInterval(renderCountdown, 250);
    player.replay();
  }

  motion.addEventListener("change", start);
  window.addEventListener("pagehide", stop);
  start();
})();
